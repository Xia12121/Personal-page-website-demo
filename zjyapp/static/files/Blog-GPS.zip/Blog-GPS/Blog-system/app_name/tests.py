from django.test import TestCase

class MyAppTests(TestCase):
    def test_something(self):
        # test something here
        pass
